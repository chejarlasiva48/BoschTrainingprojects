package com.bookstore.model;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.server.ConfigurableWebServerFactory;
import org.springframework.stereotype.Component;

@SpringBootApplication
public class BookStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookStoreApplication.class, args);
	}
	@Component
	class ServerPortCustomizer implements WebServerFactoryCustomizer<ConfigurableWebServerFactory> {
	    @Override
	    public void customize(ConfigurableWebServerFactory factory) {
	        factory.setPort(8080);  // Change port here
	    }
}
}
