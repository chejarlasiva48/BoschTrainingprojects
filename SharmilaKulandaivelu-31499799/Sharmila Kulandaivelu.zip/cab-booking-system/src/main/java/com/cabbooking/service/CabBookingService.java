package com.cabbooking.service;

import com.cabbooking.model.CabBooking;
import com.cabbooking.repository.CabBookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CabBookingService {
    @Autowired
    private CabBookingRepository cabBookingRepository;

    public CabBooking bookCab(CabBooking cabBooking) {
        return cabBookingRepository.save(cabBooking);
    }

    public List<CabBooking> getAllBookings() {
        return cabBookingRepository.findAll();
    }
}
