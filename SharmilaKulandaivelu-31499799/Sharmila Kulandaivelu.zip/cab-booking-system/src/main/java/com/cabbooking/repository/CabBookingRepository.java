package com.cabbooking.repository;

import com.cabbooking.model.CabBooking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CabBookingRepository extends JpaRepository<CabBooking, Long> {
}
