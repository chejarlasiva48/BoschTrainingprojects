package com.cabbooking.controller;

import com.cabbooking.model.CabBooking;
import com.cabbooking.service.CabBookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/bookings")
public class CabBookingController {
    @Autowired
    private CabBookingService cabBookingService;

    @PostMapping("/book")
    public CabBooking bookCab(@RequestBody CabBooking cabBooking) {
        return cabBookingService.bookCab(cabBooking);
    }

    @GetMapping
    public List<CabBooking> getAllBookings() {
        return cabBookingService.getAllBookings();
    }
}
