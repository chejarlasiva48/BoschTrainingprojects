package com.bosch.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bosch.dao.IUserRepo;
import com.bosch.model.User;

import jakarta.transaction.Transactional;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

@Service
public class UserService implements IUserService {

    @Autowired
    private IUserRepo userRepository;

    private final BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

    

	@Override
	@Transactional
	public String registerUser(User user) {
		if (userRepository.findByEmail(user.getEmail()) != null) {
            return "Email already in use";
        }

        // Encrypt password before saving
        String encryptedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encryptedPassword);

        // Save user to the database
        userRepository.save(user);
        return "User registered successfully";
	}

	@Override
	public User loginUser(String username) {
		if (userRepository.findByEmail(username) != null) {
            return userRepository.findByEmail(username);
        } else {
        	return userRepository.findByEmail(username);
        }
	}
}
