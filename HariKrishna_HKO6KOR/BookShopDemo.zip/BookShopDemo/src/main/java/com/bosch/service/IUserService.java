package com.bosch.service;

import com.bosch.model.User;

public interface IUserService {
	String registerUser(User user);

	User loginUser(String username);
}
