package com.bosch.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bosch.dao.iOrderRepo;
import com.bosch.model.Book;
import com.bosch.model.Order;


@Service
public class BookOrderService implements iBookOrderService{
	
	@Autowired
    BookDetailsService bookService;

    @Autowired
    private iOrderRepo orderRepository;

	@Override
	public Order createOrder(Long bookId, Integer quantity) {
		

		Book book = bookService.getBookById(bookId);
		Order order = new Order();
        if (book != null) {
        	
            order.setBookId(bookId);
            order.setQuantity(quantity);
            order.setTotalPrice(Double.valueOf(book.getBookPrice() * quantity));
        }
        return orderRepository.save(order);
	}
            
  
}
