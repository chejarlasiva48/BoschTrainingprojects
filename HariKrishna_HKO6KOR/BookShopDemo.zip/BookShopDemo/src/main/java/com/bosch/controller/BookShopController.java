package com.bosch.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bosch.model.Book;
import com.bosch.service.BookDetailsService;

@RestController
@RequestMapping("/bookshop")
public class BookShopController {
	@Autowired
    private BookDetailsService bookDetailsService;

    @GetMapping("/view-books")
    public List<Book> viewBooks() {
        return bookDetailsService.getAllBooks();
    }

    @PostMapping("/add")
    public ResponseEntity<String> addBook(@RequestBody Book book) {
    	String result =  bookDetailsService.addNewBook(book);
    	if(result.equals("Book added successfully.")) {
    		 return ResponseEntity.ok(result);
    	} else {
    		 return ResponseEntity.badRequest().body(result);
    	}
    }

    @DeleteMapping("/remove/{id}")
    public void removeBook(@PathVariable Long id) {
    	bookDetailsService.removeBook(id);
    }

    @PutMapping("/update/{id}/{price}")
    public void updateBookPrice(@PathVariable Long id, @PathVariable int price) {
    	bookDetailsService.updateBookPrice(id, price);
    }
}
