package com.bosch.service;

import java.util.List;

import com.bosch.model.Book;

public interface iBookDetailsService {
	List<Book> getAllBooks();

	String addNewBook(Book book);

	void removeBook(Long id);

	void updateBookPrice(Long id, int price);

	Book getBookById(Long bookId);
}
