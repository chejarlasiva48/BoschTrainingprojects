package com.bosch.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bosch.model.Book;


public interface IBookRepo extends JpaRepository <Book, Long> {

}
