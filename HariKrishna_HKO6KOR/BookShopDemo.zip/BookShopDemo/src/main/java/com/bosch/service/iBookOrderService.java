package com.bosch.service;

import com.bosch.model.Order;

public interface iBookOrderService {
	Order createOrder(Long bookId, Integer quantity);
}
