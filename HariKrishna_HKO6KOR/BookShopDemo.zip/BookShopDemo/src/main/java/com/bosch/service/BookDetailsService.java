package com.bosch.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bosch.dao.IBookRepo;
import com.bosch.model.Book;

@Service
public class BookDetailsService implements iBookDetailsService {
	@Autowired
	private IBookRepo bookRepository;
	
	@Override
	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	@Override
	public String addNewBook(Book book) {
		if(getAllBooks() != null && getAllBooks().contains(book)) {
			 return "Book Already Exists.";
		 } else {
			 bookRepository.save(book);
			 return "Book added successfully.";
		 }
	}

	@Override
	public void removeBook(Long id) {
		bookRepository.deleteById(id);
		
	}

	@Override
	public void updateBookPrice(Long id, int price) {
		Book book = bookRepository.findById(id).orElse(null); 
		if (book != null) {
				 book.setBookPrice(price); 
				 bookRepository.save(book); 
		}
		
	}

	@Override
	public Book getBookById(Long bookId) {
		// TODO Auto-generated method stub
		return bookRepository.findById(bookId).orElse(null);
	}


}
