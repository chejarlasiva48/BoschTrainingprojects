package com.bosch.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.bosch.dao.IBookRepo;
import com.bosch.model.Book;

public class BookDetailsService implements iBookDetailsService {
	@Autowired
	private IBookRepo bookRepository;
	
	@Override
	public List<Book> getAllBooks() {
		return bookRepository.findAll();
	}

	@Override
	public String addNewBook(Book book) {
		if(getAllBooks() != null && getAllBooks().contains(book)) {
			 return "Book Already Exists.";
		 } else {
			 bookRepository.save(book);
			 return "Book added successfully.";
		 }
	}

	@Override
	public void removeBook(Long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBookPrice(Long id, int price) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Book getBookById(Long bookId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

	/*
	 * public List<Book> getAllBooks() { return bookRepository.findAll(); }
	 * 
	 * public void addNewBook(Book book) { bookRepository.save(book); }
	 * 
	 * public void removeBook(Long id) { bookRepository.deleteById(id); }
	 * 
	 * public void updateBookPrice(Long id, int price) { Book book =
	 * bookRepository.findById(id).orElse(null); if (book != null) {
	 * book.setQuantity(price); bookRepository.save(book); } }
	 * 
	 * @Override public Book getBookById(Long bookId) { return
	 * bookRepository.findById(bookId).orElse(null); }
	 */

}
